#include <gtk/gtk.h>
///////////////////ajout seance/////////////////////////////
typedef struct
{
int jour;
int mois;
int annee;
int numero;

}date;
typedef struct
{
char heure[50];
char categorie[50];
char nom[50];
char typesc[50];
}seance;

void ajout_seance(seance s, date d);
void afficher_seance(GtkWidget *liste);
void supprimer(int choix);
int verif (seance s,date d);

///////////modification pour ajout seance/////////
void modifier_seance (seance s, date d);
/*
int verif_modif_seance (seance s,date d);
///////////////////ajout disponibilité/////////////////////////////*/
typedef struct
{
int num;
int jour3;
int mois3;
int annee3;
}day;
typedef struct
{
char jour_disp[50];
char pres[50];
}jour;


void ajout_disp(day da, jour j);
void afficher_disponibilite (GtkWidget *liste);
void supprimer_disp(int choix2);
int verif_disp (day da,jour j);
void modifier_disponibilite (jour j, day da);
/*
////////////////ajout profil///////

typedef struct
{
char Nom;
char Prenom;
char Cin;
char Age;
char Numero
}profil;


ajouter_profil_coach(profil p);

*/



typedef struct
{
char msg1[50];
}message;

void ajout_message(message me);





