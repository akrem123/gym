#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "verifier.h"
#include "personne.h"
#include "ajout.h"
///////////pour l'autentification/////////////////////

void on_button1_clicked (GtkWidget  *Widget, gpointer user_data)
{
GtkWidget *Username;
GtkWidget *Password;
GtkWidget *role;
GtkWidget *DIET;
GtkWidget *erreur;
GtkWidget *coach;
GtkWidget *window1;

DIET=create_DIET();
coach=create_coach();







int role12;
char Username12[30];
char Password12[30];
erreur=lookup_widget(Widget,"label5");
Username=lookup_widget(Widget,"entry1");
Password=lookup_widget(Widget,"entry2");
//role=lookup_widget(widget,"role");
strcpy(Username12,gtk_entry_get_text(GTK_ENTRY(Username)));
strcpy(Password12,gtk_entry_get_text(GTK_ENTRY(Password)));
role12=verifier(Username12,Password12);
window1=lookup_widget(Widget,"window1");

switch (role12)

{case 1:gtk_widget_show(DIET);
gtk_widget_hide(window1);

break;
case 2:gtk_widget_show(coach);
gtk_widget_hide(window1);
break;
default:gtk_label_set_text(GTK_LABEL(erreur),"erreur d'authentification");}







}
void
on_button2_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{

GtkWidget *coach;
GtkWidget *window3;
GtkWidget *treeview1;

coach=lookup_widget(objet_graphique,"coach");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(coach);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}
////////////////////bouton d'ajout avec verification/////////////

void
on_button6_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
int x;
int jour1;
int mois1;
int annee1;
int numero1;
char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
seance s;
date d;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *numero;
GtkWidget *combobox1; 
GtkWidget *combobox2;
GtkWidget *combobox3; 
GtkWidget *combobox4;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label17");
jour=lookup_widget(objet_graphique,"jour");
numero=lookup_widget(objet_graphique,"numero");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
combobox1=lookup_widget(objet_graphique,"combobox1");
combobox2=lookup_widget(objet_graphique,"combobox2"); 
combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");    
 
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(s.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(s.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(s.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(s.typesc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

x=verif(s,d);

if(x==0)
{
ajout_seance(s,d);
}
else 
gtk_label_set_text(GTK_LABEL(erreur),"planning existant");
}



void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *win;
GtkWidget *wip;


win=create_window3();
wip=lookup_widget(objet_graphique,"window2");

gtk_widget_show(win);
gtk_widget_hide(wip);
GtkWidget *window3;
GtkWidget *window2;
GtkWidget *treeview1;
GtkWidget *erreur;
window2=lookup_widget(objet_graphique,"window2");
erreur=lookup_widget(objet_graphique,"label17");
gtk_label_set_text(GTK_LABEL(erreur),"test ajout");
window3=lookup_widget(objet_graphique,"window3");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(win);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1); 


}



void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2,*coach;
coach=lookup_widget(objet_graphique,"coach");
gtk_widget_destroy(window2);
coach=create_coach();
gtk_widget_show(coach);

}


void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window3;
coach=lookup_widget(objet_graphique,"coach");
window3=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window3);
coach=create_coach();
gtk_widget_show(coach);

}


void
on_button11_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
GtkWidget *coach;
GtkWidget *window5;
GtkWidget *treeview2;

coach=lookup_widget(objet_graphique,"coach");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(coach);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);


}






void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window2();
wip=lookup_widget(objet_graphique,"window3");

gtk_widget_show(win);
gtk_widget_hide(wip);}


//////////////////pour la disponibilité/////////////////

void
on_button12_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
int x;
int num33;
int jour33;
int mois33;
int annee33;
char jour_disp33[30];
char pres33[30];

jour j;
day da;

GtkWidget *num;
GtkWidget *jour_disp;
GtkWidget *jour3;
GtkWidget *mois3;
GtkWidget *annee3; 
GtkWidget *pres;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label45");
num=lookup_widget(objet_graphique,"num");

jour_disp=lookup_widget(objet_graphique,"jour_disp");
jour3=lookup_widget(objet_graphique,"jour3"); 
mois3=lookup_widget(objet_graphique,"mois3");
annee3=lookup_widget(objet_graphique,"annee3");    
pres=lookup_widget(objet_graphique,"pres");

 
 
da.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));
da.jour3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour3));
da.mois3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois3));
da.annee3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee3));



strcpy(j.jour_disp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour_disp)));
strcpy(j.pres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(pres)));




x=verif_disp(da,j);


if(x==0)
{
ajout_disp( da,j);
}
else 
gtk_label_set_text(GTK_LABEL(erreur),"planning existant");
}




void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window5();
wip=lookup_widget(objet_graphique,"window4");

gtk_widget_show(win);
gtk_widget_hide(wip);
GtkWidget *window5;
GtkWidget *window4;
GtkWidget *treeview2;
window5=lookup_widget(objet_graphique,"window5");
window4=lookup_widget(objet_graphique,"window4");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(win);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2); 
}




void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window5;


window5=lookup_widget(objet_graphique,"window5");
coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(window5);
}


void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window4();
wip=lookup_widget(objet_graphique,"window5");

gtk_widget_show(win);
gtk_widget_hide(wip);
}

/*
void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *window6;


window3=lookup_widget(objet_graphique,"window3");
window6=create_window6();
gtk_widget_show(window6);
gtk_widget_hide(window3);



}
*/

////////////////////////////le bouton supprimer///////////////
void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *window6;
GtkWidget *choix;

choix=lookup_widget(objet_graphique,"choix");
  
 
choix=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (choix));

supprimer(choix);


}





////////////////////////aller au window6 pour la suppressions///////////////////////

void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window6;
GtkWidget *window3;




window3=lookup_widget(objet_graphique,"window3");
window6=create_window6();
gtk_widget_show(window6);
gtk_widget_hide(window3);



}

////////////////////////le retour apres la supression et l'affichage///////////////////
void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window6;
GtkWidget *window3;
GtkWidget *treeview1;



window6=lookup_widget(objet_graphique,"window6");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(window6);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}




///////////////pour le bouton supprimer de dispo///////////
void
on_button30_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *choix2;

choix2=lookup_widget(objet_graphique,"choix2");
  
 
choix2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (choix2));

supprimer_disp(choix2);


}




////////////////////////le retour apres la supression et l'affichage de la disp///////////////////


void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window7;
GtkWidget *window5;
GtkWidget *treeview2;



window7=lookup_widget(objet_graphique,"window7");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(window7);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);
}





void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window7;
GtkWidget *window5;

window5=lookup_widget(objet_graphique,"window5");
window7=create_window7();
gtk_widget_show(window7);
gtk_widget_hide(window5);
}



//////////nous ramene vers la surface de modification////////////
void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window3;
GtkWidget *window9;
GtkWidget *treeview1;

window3=lookup_widget(objet_graphique,"window3");
window9=create_window9();
gtk_widget_show(window9);
gtk_widget_hide(window3);

}

//////// affiche les modification///////
void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window9;
GtkWidget *window3;
GtkWidget *treeview1;

window9=lookup_widget(objet_graphique,"window9");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(window9);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}


/////////////valide la modification/////////////
void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int x;
int jour1;
int mois1;
int annee1;
int numero1;
char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
seance s;
date d;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *numero;
GtkWidget *combobox1; 
GtkWidget *combobox2;
GtkWidget *combobox3; 
GtkWidget *combobox4;
//GtkWidget *erreur;


//erreur=lookup_widget(objet_graphique,"label66");
jour=lookup_widget(objet_graphique,"jour");
numero=lookup_widget(objet_graphique,"numero");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
combobox1=lookup_widget(objet_graphique,"combobox1");
combobox2=lookup_widget(objet_graphique,"combobox2"); 
combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");    
 
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(s.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(s.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(s.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(s.typesc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

//x=verif(s,d);

//if(x==0)
//{
modifier_seance (s, d);
//}
//else 
//gtk_label_set_text(GTK_LABEL(erreur),"faute de numero");
}




/////////////bouton qui valide la modification de la disponibilité/////////////


void
on_button39_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{

int num33;
int jour33;
int mois33;
int annee33;
char jour_disp33[30];
char pres33[30];

jour j;
day da;

GtkWidget *num;
GtkWidget *jour_disp;
GtkWidget *jour3;
GtkWidget *mois3;
GtkWidget *annee3; 
GtkWidget *pres;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label45");
num=lookup_widget(objet_graphique,"num");

jour_disp=lookup_widget(objet_graphique,"jour_disp");
jour3=lookup_widget(objet_graphique,"jour3"); 
mois3=lookup_widget(objet_graphique,"mois3");
annee3=lookup_widget(objet_graphique,"annee3");    
pres=lookup_widget(objet_graphique,"pres");

 
 
da.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));
da.jour3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour3));
da.mois3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois3));
da.annee3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee3));



strcpy(j.jour_disp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour_disp)));
strcpy(j.pres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(pres)));


modifier_disponibilite ( j, da);


}





//////////bouton qui nous ramene vers la surface de modification//////

void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5;
GtkWidget *window10;


window5=lookup_widget(objet_graphique,"window5");
window10=create_window10();
gtk_widget_show(window10);
gtk_widget_hide(window5);
}

///////////////bouton qui fait l'affichage de la modification de disp///////
void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10;
GtkWidget *window5;
GtkWidget *treeview2;

window10=lookup_widget(objet_graphique,"window10");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(window10);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);
}


/*

void
on_button41_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data)



{
GtkWidget *Nom;
GtkWidget *Prenom;
GtkWidget *Cin;
GtkWidget *Numero;
GtkWidget *Age;

char Nom[30] ; 
char Prenom[30] ;
char Cin[30] ;
char Numero[20] ; 
char Age[20] ;

Nom=lookup_widget(widget,"Nom");
Prenom=lookup_widget(widget,"Prenom");
Cin=lookup_widget(widget,"Cin");
Age=lookup_widget(widget,"Age");
Numero=lookup_widget(widget,"Numero");
strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(Nom));
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom));
strcpy(Cin,gtk_entry_get_text(GTK_ENTRY(Cin));
strcpy(Age,gtk_entry_get_text(GTK_ENTRY(Age));
strcpy(Numero,gtk_entry_get_text(GTK_ENTRY(Numero));

ajouter_profil_coach(Nom,Prenom,Cin,Age,Numero);
gtk_widget_destroy(coach);
window11=create_window11();
gtk_widget_show(window11);
}


void
on_button40_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;

coach=lookup_widget(objet_graphique,"coach");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(coach);

}*/


void
on_button_seance_di_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_ajouter;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
diet_seance_ajouter=create_diet_seance_ajouter();
gtk_widget_show(diet_seance_ajouter);
}


void
on_button_dispo_di_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter_dispo;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
fenetre_ajouter_dispo=create_fenetre_ajouter_dispo();
gtk_widget_show(fenetre_ajouter_dispo);
}


void
on_button_ajout_regime_di_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_ajout_regime;
//DIET = create_DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy (DIET);
fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");
fenetre_ajout_regime=create_fenetre_ajout_regime();
gtk_widget_show(fenetre_ajout_regime);


}


void
on_button_cnx_di_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *DIET;
DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
DIET=lookup_widget(objet,"window1");
window1=create_window1();
gtk_widget_show(window1);
}


void
on_button_ajout_diet_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
Personne p;

GtkWidget *input1, *input2,*input3,*input4,*input5;
GtkWidget *fenetre_ajout_regime;

fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");

input1=lookup_widget(objet,"type_diet");
input2=lookup_widget(objet,"date_debut_diet");
input3=lookup_widget(objet,"date_fin_diet");
input4=lookup_widget(objet,"date_diet");
input5=lookup_widget(objet,"Lieux_diet");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));



ajouter_regime_di(p);


}


void
on_button_afficher_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_regime;
GtkWidget *fenetre_afficher_regime;
GtkWidget *treeview1_diet;

fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");


gtk_widget_destroy(fenetre_ajout_regime);
fenetre_afficher_regime=lookup_widget(objet,"fenetre_afficher_regime");
fenetre_afficher_regime=create_fenetre_afficher_regime();

gtk_widget_show(fenetre_afficher_regime);
      

treeview1_diet=lookup_widget(fenetre_afficher_regime,"treeview1_diet");

afficher_diet_di(treeview1_diet); 


}


void
on_button_retour_regime_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_regime;
GtkWidget *DIET;
fenetre_ajout_regime=lookup_widget(objet,"fenetre_ajout_regime");
gtk_widget_destroy(fenetre_ajout_regime);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);
}


void
on_button_retour_liste1_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_regime, *fenetre_afficher_regime;

fenetre_afficher_regime=lookup_widget(objet,"fenetre_afficher_regime");


gtk_widget_destroy(fenetre_afficher_regime);
fenetre_ajout_regime=create_fenetre_ajout_regime();
gtk_widget_show(fenetre_ajout_regime);

}


void
on_button_menu_diet_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_modifier;
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
gtk_widget_destroy(diet_seance_modifier);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);


}


void
on_button_ajouter_disp_diet_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{

int jour10;
int mois10;
int annee10;
char combobox10[50];
seance1 y;
date1 z;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *combobox1;
//GtkWidget *message;
//message=lookup_widget(objet,"MESSAGE_DIET");
jour=lookup_widget(objet,"spinbutton1_diet");
mois=lookup_widget(objet,"spinbutton2_diet");
annee=lookup_widget(objet,"spinbutton3_diet");
combobox1=lookup_widget(objet,"combobox1_diet");


z.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
z.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
z.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(y.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
//x=verif_dispo_di(y,z);


ajout_seance_di(y,z);

}








void
on_button_afficher_disp_diet_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter_dispo;
GtkWidget *fenetre_afficher_dispo;
GtkWidget *treeview2_diet;
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
gtk_widget_destroy(fenetre_ajouter_dispo);
fenetre_afficher_dispo=lookup_widget(objet,"fenetre_afficher_dispo");
fenetre_afficher_dispo=create_fenetre_afficher_dispo();
gtk_widget_show(fenetre_afficher_dispo);
treeview2_diet=lookup_widget(fenetre_afficher_dispo,"treeview2_diet");

afficher_seance_di(treeview2_diet); 
}


void
on_button_retour2_disp_diet_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher_dispo;
GtkWidget *fenetre_ajouter_dispo;
//GtkWidget *treeview2;
fenetre_afficher_dispo=lookup_widget(objet,"fenetre_afficher_dispo");
gtk_widget_destroy(fenetre_afficher_dispo);
fenetre_ajouter_dispo=lookup_widget(objet,"fenetre_ajouter_dispo");
fenetre_ajouter_dispo=create_fenetre_ajouter_dispo();
//treeview2=lookup_widget(fenetre_afficher_dispo,"treeview2");
gtk_widget_show(fenetre_ajouter_dispo);
//treeview2=lookup_widget(fenetre_afficher_dispo,"treeview2");
//afficher_seance(treeview2); 
}


void
on_button_afficherseance_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_ajouter;
GtkWidget *treeview3_diet;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);
treeview3_diet=lookup_widget(diet_affich_seance,"treeview3_diet");
afficher_seance2_di(treeview3_diet); 
}


void
on_button_ajouter3_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
seance2 b;
date2 a;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *seance_diet;
GtkWidget *objectif_diet;
GtkWidget *numero;

//GtkWidget *erreur;
jour=lookup_widget(objet,"spinbutton4_diet");
mois=lookup_widget(objet,"spinbutton5_diet");
annee=lookup_widget(objet,"spinbutton6_diet");
seance_diet=lookup_widget(objet,"entry3_diet");
objectif_diet=lookup_widget(objet,"entry4_diet");
numero=lookup_widget(objet,"spinbutton_numero");

a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(b.name_seance,gtk_entry_get_text(GTK_ENTRY(seance_diet)));
strcpy(b.objectif_seance,gtk_entry_get_text(GTK_ENTRY(objectif_diet)));
a.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));

ajout_seance2_di(b,a);
}


void
on_button_retour_ajoutseance_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_ajouter;
GtkWidget *DIET;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);
}


void
on_button_modifier_diet_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_modifier;
GtkWidget *diet_affich_seance;
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
gtk_widget_destroy(diet_affich_seance);
diet_seance_modifier=lookup_widget(objet,"diet_seance_modifier");
diet_seance_modifier=create_diet_seance_modifier();
gtk_widget_show(diet_seance_modifier);
}


void
on_button_supprimer_diet_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *spinbutton8_diet;
//GtkWidget *diet_affich_seance;
//diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
spinbutton8_diet=lookup_widget(objet,"spinbutton8_diet");
spinbutton8_diet=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton8_diet));
supprimer(spinbutton8_diet);
}


void
on_button_retour5_diet_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
 
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_ajouter;
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
gtk_widget_destroy(diet_affich_seance);
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
diet_seance_ajouter=create_diet_seance_ajouter();
gtk_widget_show(diet_seance_ajouter);
}


void
on_button_afficher_dietseance_clicked  (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_affich_seance;
GtkWidget *diet_seance_ajouter;
GtkWidget *treeview3_diet;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
diet_affich_seance=lookup_widget(objet,"diet_affich_seance");
diet_affich_seance=create_diet_affich_seance();
gtk_widget_show(diet_affich_seance);
treeview3_diet=lookup_widget(diet_affich_seance,"treeview3_diet");
afficher_seance2_di(treeview3_diet); 
}



void
on_button_modifier_dietseance_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
seance2 b;
date2 a;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *seance_diet;
GtkWidget *objectif_diet;
GtkWidget *numero;

//GtkWidget *erreur;
jour=lookup_widget(objet,"spinbutton4_diet");
mois=lookup_widget(objet,"spinbutton5_diet");
annee=lookup_widget(objet,"spinbutton6_diet");
seance_diet=lookup_widget(objet,"entry3_diet");
objectif_diet=lookup_widget(objet,"entry4_diet");
numero=lookup_widget(objet,"spinbutton_numero");

a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(b.name_seance,gtk_entry_get_text(GTK_ENTRY(seance_diet)));
strcpy(b.objectif_seance,gtk_entry_get_text(GTK_ENTRY(objectif_diet)));
a.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));

modifier_seance_di (b,a);
}



void
on_button_retour_dietseance_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *diet_seance_ajouter;
GtkWidget *DIET;
diet_seance_ajouter=lookup_widget(objet,"diet_seance_ajouter");
gtk_widget_destroy(diet_seance_ajouter);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);





}


void
on_button_message_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;


coach=lookup_widget(objet_graphique,"coach");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(coach);

}


void
on_button_ajouter_message_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
message me;

GtkWidget *aa;
aa=lookup_widget(objet_graphique,"entry3_msg");
strcpy(me.msg1,gtk_entry_get_text(GTK_ENTRY(aa)));
ajouter_message(me);
}


void
on_button_afficher_message_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
char aa[30];
GtkWidget *output;
FILE *f;
message me;
f=fopen("message_coach.txt","r");
if (f!=NULL)
{while (fscanf(f,"%s\n",me.msg1)!=EOF)
{
output=lookup_widget(objet_graphique,"labelxx");
gtk_label_set_text(GTK_LABEL(output),me.msg1);
}
fclose(f);
}
}



void
on_button_retour_menu_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;


window11=lookup_widget(objet_graphique,"window11");
coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(window11);
}


void
on_button_afficher_msg_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
char aa[30];
GtkWidget *output;
FILE *f;
envoi m;
f=fopen("message_dietitien.txt","r");
if (f!=NULL)
{while (fscanf(f,"%s\n",m.mess)!=EOF)
{
output=lookup_widget(objet,"affich_msg");
gtk_label_set_text(GTK_LABEL(output),m.mess);
}
fclose(f);
}
}



void
on_valider_msg_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
envoi m;
GtkWidget *input1;
input1=lookup_widget(objet,"entry_message");

strcpy(m.mess,gtk_entry_get_text(GTK_ENTRY(input1)));
ajout_envoi(m);
}

/*
void
on_button_retour_menu_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{

}
*/

void
on_Contact_coach_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_contact_coach;


DIET=lookup_widget(objet,"DIET");
gtk_widget_destroy(DIET);
//////////////
fenetre_contact_coach=lookup_widget(objet,"fenetre_contact_coach");
fenetre_contact_coach=create_fenetre_contact_coach();
gtk_widget_show(fenetre_contact_coach);
}


void
on_button_retour_diet3_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *DIET;
GtkWidget *fenetre_contact_coach;


fenetre_contact_coach=lookup_widget(objet,"fenetre_contact_coach");
gtk_widget_destroy(fenetre_contact_coach);
DIET=lookup_widget(objet,"DIET");
DIET=create_DIET();
gtk_widget_show(DIET);

}


void
on_button_deconnexion_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window1;


coach=lookup_widget(objet_graphique,"coach");
window1=create_window1();
gtk_widget_show(window1);
gtk_widget_hide(coach);
}

