#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "verifier.h"
#include "ajout.h"
///////////pour l'autentification/////////////////////

void on_button1_clicked (GtkWidget  *Widget, gpointer user_data)
{
GtkWidget *Username;
GtkWidget *Password;
GtkWidget *role;
GtkWidget *Admin;
GtkWidget *erreur;
GtkWidget *coach;
GtkWidget *window1;
Admin=create_Admin();
coach=create_coach();

int role12;
char Username12[30];
char Password12[30];
erreur=lookup_widget(Widget,"label5");
Username=lookup_widget(Widget,"entry1");
Password=lookup_widget(Widget,"entry2");
//role=lookup_widget(widget,"role");
strcpy(Username12,gtk_entry_get_text(GTK_ENTRY(Username)));
strcpy(Password12,gtk_entry_get_text(GTK_ENTRY(Password)));
role12=verifier(Username12,Password12);
window1=lookup_widget(Widget,"window1");
switch (role12)

{case 1:gtk_widget_show(Admin);
gtk_widget_hide(window1);
break;
case 2:gtk_widget_show(coach);
gtk_widget_hide(window1);
break;
default:gtk_label_set_text(GTK_LABEL(erreur),"erreur d'authentification");}
}
void
on_button2_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{

GtkWidget *coach;
GtkWidget *window3;
GtkWidget *treeview1;

coach=lookup_widget(objet_graphique,"coach");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(coach);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}
////////////////////bouton d'ajout avec verification/////////////

void
on_button6_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
int x;
int jour1;
int mois1;
int annee1;
int numero1;
char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
seance s;
date d;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *numero;
GtkWidget *combobox1; 
GtkWidget *combobox2;
GtkWidget *combobox3; 
GtkWidget *combobox4;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label17");
jour=lookup_widget(objet_graphique,"jour");
numero=lookup_widget(objet_graphique,"numero");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
combobox1=lookup_widget(objet_graphique,"combobox1");
combobox2=lookup_widget(objet_graphique,"combobox2"); 
combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");    
 
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(s.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(s.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(s.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(s.typesc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

x=verif(s,d);

if(x==0)
{
ajout_seance(s,d);
}
else 
gtk_label_set_text(GTK_LABEL(erreur),"planning existant");
}



void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *win;
GtkWidget *wip;


win=create_window3();
wip=lookup_widget(objet_graphique,"window2");

gtk_widget_show(win);
gtk_widget_hide(wip);
GtkWidget *window3;
GtkWidget *window2;
GtkWidget *treeview1;
GtkWidget *erreur;
window2=lookup_widget(objet_graphique,"window2");
erreur=lookup_widget(objet_graphique,"label17");
gtk_label_set_text(GTK_LABEL(erreur),"test ajout");
window3=lookup_widget(objet_graphique,"window3");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(win);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1); 


}



void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2,*coach;
coach=lookup_widget(objet_graphique,"coach");
gtk_widget_destroy(window2);
coach=create_coach();
gtk_widget_show(coach);

}


void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window3;
coach=lookup_widget(objet_graphique,"coach");
window3=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window3);
coach=create_coach();
gtk_widget_show(coach);

}


void
on_button11_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
GtkWidget *coach;
GtkWidget *window5;
GtkWidget *treeview2;

coach=lookup_widget(objet_graphique,"coach");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(coach);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);


}






void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window2();
wip=lookup_widget(objet_graphique,"window3");

gtk_widget_show(win);
gtk_widget_hide(wip);}


//////////////////pour la disponibilité/////////////////

void
on_button12_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{
int x;
int num33;
int jour33;
int mois33;
int annee33;
char jour_disp33[30];
char pres33[30];

jour j;
day da;

GtkWidget *num;
GtkWidget *jour_disp;
GtkWidget *jour3;
GtkWidget *mois3;
GtkWidget *annee3; 
GtkWidget *pres;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label45");
num=lookup_widget(objet_graphique,"num");

jour_disp=lookup_widget(objet_graphique,"jour_disp");
jour3=lookup_widget(objet_graphique,"jour3"); 
mois3=lookup_widget(objet_graphique,"mois3");
annee3=lookup_widget(objet_graphique,"annee3");    
pres=lookup_widget(objet_graphique,"pres");

 
 
da.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));
da.jour3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour3));
da.mois3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois3));
da.annee3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee3));



strcpy(j.jour_disp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour_disp)));
strcpy(j.pres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(pres)));




x=verif_disp(da,j);


if(x==0)
{
ajout_disp( da,j);
}
else 
gtk_label_set_text(GTK_LABEL(erreur),"planning existant");
}




void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window5();
wip=lookup_widget(objet_graphique,"window4");

gtk_widget_show(win);
gtk_widget_hide(wip);
GtkWidget *window5;
GtkWidget *window4;
GtkWidget *treeview2;
window5=lookup_widget(objet_graphique,"window5");
window4=lookup_widget(objet_graphique,"window4");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(win);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2); 
}




void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window5;


window5=lookup_widget(objet_graphique,"window5");
coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(window5);
}


void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *win;
GtkWidget *wip;


win=create_window4();
wip=lookup_widget(objet_graphique,"window5");

gtk_widget_show(win);
gtk_widget_hide(wip);
}

/*
void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *window6;


window3=lookup_widget(objet_graphique,"window3");
window6=create_window6();
gtk_widget_show(window6);
gtk_widget_hide(window3);



}
*/

////////////////////////////le bouton supprimer///////////////
void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *window6;
GtkWidget *choix;

choix=lookup_widget(objet_graphique,"choix");
  
 
choix=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (choix));

supprimer(choix);


}





////////////////////////aller au window6 pour la suppressions///////////////////////

void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window6;
GtkWidget *window3;




window3=lookup_widget(objet_graphique,"window3");
window6=create_window6();
gtk_widget_show(window6);
gtk_widget_hide(window3);



}

////////////////////////le retour apres la supression et l'affichage///////////////////
void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window6;
GtkWidget *window3;
GtkWidget *treeview1;



window6=lookup_widget(objet_graphique,"window6");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(window6);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}




///////////////pour le bouton supprimer de dispo///////////
void
on_button30_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *choix2;

choix2=lookup_widget(objet_graphique,"choix2");
  
 
choix2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (choix2));

supprimer_disp(choix2);


}




////////////////////////le retour apres la supression et l'affichage de la disp///////////////////


void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window7;
GtkWidget *window5;
GtkWidget *treeview2;



window7=lookup_widget(objet_graphique,"window7");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(window7);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);
}





void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window7;
GtkWidget *window5;

window5=lookup_widget(objet_graphique,"window5");
window7=create_window7();
gtk_widget_show(window7);
gtk_widget_hide(window5);
}



//////////nous ramene vers la surface de modification////////////
void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window3;
GtkWidget *window9;
GtkWidget *treeview1;

window3=lookup_widget(objet_graphique,"window3");
window9=create_window9();
gtk_widget_show(window9);
gtk_widget_hide(window3);

}

//////// affiche les modification///////
void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window9;
GtkWidget *window3;
GtkWidget *treeview1;

window9=lookup_widget(objet_graphique,"window9");
window3=create_window3();
gtk_widget_show(window3);
gtk_widget_hide(window9);
treeview1=lookup_widget(window3,"treeview1");
afficher_seance(treeview1);
}


/////////////valide la modification/////////////
void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int x;
int jour1;
int mois1;
int annee1;
int numero1;
char combobox11[30];
char combobox12[30];
char combobox13[30];
char combobox14[30];
seance s;
date d;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *numero;
GtkWidget *combobox1; 
GtkWidget *combobox2;
GtkWidget *combobox3; 
GtkWidget *combobox4;
//GtkWidget *erreur;


//erreur=lookup_widget(objet_graphique,"label66");
jour=lookup_widget(objet_graphique,"jour");
numero=lookup_widget(objet_graphique,"numero");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
combobox1=lookup_widget(objet_graphique,"combobox1");
combobox2=lookup_widget(objet_graphique,"combobox2"); 
combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");    
 
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.numero=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (numero));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(s.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(s.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(s.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(s.typesc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

//x=verif(s,d);

//if(x==0)
//{
modifier_seance (s, d);
//}
//else 
//gtk_label_set_text(GTK_LABEL(erreur),"faute de numero");
}




/////////////bouton qui valide la modification de la disponibilité/////////////


void
on_button39_clicked (GtkWidget  *objet_graphique, gpointer user_data)
{

int num33;
int jour33;
int mois33;
int annee33;
char jour_disp33[30];
char pres33[30];

jour j;
day da;

GtkWidget *num;
GtkWidget *jour_disp;
GtkWidget *jour3;
GtkWidget *mois3;
GtkWidget *annee3; 
GtkWidget *pres;
GtkWidget *erreur;


erreur=lookup_widget(objet_graphique,"label45");
num=lookup_widget(objet_graphique,"num");

jour_disp=lookup_widget(objet_graphique,"jour_disp");
jour3=lookup_widget(objet_graphique,"jour3"); 
mois3=lookup_widget(objet_graphique,"mois3");
annee3=lookup_widget(objet_graphique,"annee3");    
pres=lookup_widget(objet_graphique,"pres");

 
 
da.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));
da.jour3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour3));
da.mois3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois3));
da.annee3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee3));



strcpy(j.jour_disp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour_disp)));
strcpy(j.pres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(pres)));


modifier_disponibilite ( j, da);


}





//////////bouton qui nous ramene vers la surface de modification//////

void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5;
GtkWidget *window10;


window5=lookup_widget(objet_graphique,"window5");
window10=create_window10();
gtk_widget_show(window10);
gtk_widget_hide(window5);
}

///////////////bouton qui fait l'affichage de la modification de disp///////
void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10;
GtkWidget *window5;
GtkWidget *treeview2;

window10=lookup_widget(objet_graphique,"window10");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_hide(window10);
treeview2=lookup_widget(window5,"treeview2");
afficher_disponibilite(treeview2);
}


/*

void
on_button41_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data)



{
GtkWidget *Nom;
GtkWidget *Prenom;
GtkWidget *Cin;
GtkWidget *Numero;
GtkWidget *Age;

char Nom[30] ; 
char Prenom[30] ;
char Cin[30] ;
char Numero[20] ; 
char Age[20] ;

Nom=lookup_widget(widget,"Nom");
Prenom=lookup_widget(widget,"Prenom");
Cin=lookup_widget(widget,"Cin");
Age=lookup_widget(widget,"Age");
Numero=lookup_widget(widget,"Numero");
strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(Nom));
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom));
strcpy(Cin,gtk_entry_get_text(GTK_ENTRY(Cin));
strcpy(Age,gtk_entry_get_text(GTK_ENTRY(Age));
strcpy(Numero,gtk_entry_get_text(GTK_ENTRY(Numero));

ajouter_profil_coach(Nom,Prenom,Cin,Age,Numero);
gtk_widget_destroy(coach);
window11=create_window11();
gtk_widget_show(window11);
}


void
on_button40_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;

coach=lookup_widget(objet_graphique,"coach");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(coach);

}*/



////////////bouton validation du message//////////
void
on_button_ajouter_message_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
message me;

GtkWidget *aa;
aa=lookup_widget(objet_graphique,"entry3_msg");
strcpy(me.msg1,gtk_entry_get_text(GTK_ENTRY(aa)));
ajouter_message(me);
}


void
on_button_retour_menu_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;


window11=lookup_widget(objet_graphique,"window11");
coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(window11);
}


void
on_button_afficher_message_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_message_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach;
GtkWidget *window11;


coach=lookup_widget(objet_graphique,"coach");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(coach);

}


void
on_button_deconnexion_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *coach;
GtkWidget *window1;


coach=lookup_widget(objet_graphique,"coach");
window1=create_window1();
gtk_widget_show(window1);
gtk_widget_hide(coach);

}


void
on_buttonprofil_co_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window12;
GtkWidget *coach;


coach=lookup_widget(objet,"coach");
window12=create_window12();
gtk_widget_show(window12);
gtk_widget_hide(coach);

}

void
on_button40_retour_coco_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window12;
GtkWidget *coach;


window12=lookup_widget(objet,"window12");
coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(window12);
}


void
on_Afficher_prof_coo_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
prof a;
char champ1[50];
char champ2[50];
char champ3[50];
char champ4[50];
char champ5[50];

GtkWidget *champ11;
GtkWidget *champ22;
GtkWidget *champ33;
GtkWidget *champ44;
GtkWidget *champ55;
FILE *f4;
f4=fopen("profile_co.txt","a+");
if (f4!=NULL)
{while (fscanf(f4,"%s %s %s %s %s\n",a.champ1,a.champ2,a.champ3,a.champ4,a.champ5)!=EOF)
{
champ11=lookup_widget(objet,"label111");
gtk_label_set_text(GTK_LABEL(champ11),a.champ1);

champ22=lookup_widget(objet,"label112");
gtk_label_set_text(GTK_LABEL(champ22),a.champ2);

champ33=lookup_widget(objet,"label113");
gtk_label_set_text(GTK_LABEL(champ33),a.champ3);

champ44=lookup_widget(objet,"label114");
gtk_label_set_text(GTK_LABEL(champ44),a.champ4);

champ55=lookup_widget(objet,"label115");
gtk_label_set_text(GTK_LABEL(champ55),a.champ5);

}
fclose(f4);

}
}


