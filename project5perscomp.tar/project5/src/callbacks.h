#include <gtk/gtk.h>


void
on_button1_clicked (GtkWidget *button, gpointer user_data);
void
on_button2_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button6_clicked (GtkWidget *objet_graphique, gpointer user_data);


void
on_button8_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button11_clicked (GtkWidget  *objet_graphique, gpointer user_data);


/*
void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
*/
void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);





void
on_button30_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button39_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
/*
void
on_button41_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button40_co_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_co_clicked                  (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_button_ajouter_message_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_menu_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_message_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_message_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_deconnexion_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonprofil_co_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button40_retour_coco_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficher_prof_coo_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);
